interface IController {

}

export default IController