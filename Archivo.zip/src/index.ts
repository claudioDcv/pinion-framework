import App from './base/App'
import Controller from './base/controller/Controller'
import Hi from './app/controller/Hi';
import Bie from './app/controller/Bie';
import Cristofer from './app/controller/Cristofer';


const app = new App(3333)

app.registerRoute('/hola', Hi)
app.registerRoute('/chao', Bie)
app.registerRoute('/cristofer', Cristofer)

app.start()