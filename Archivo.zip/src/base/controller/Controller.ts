import Props from "./Props";
import TemplateEngine from "../view/TemplateEngine";
import IController from "./IController";

class Controller implements IController{

    public model = {}
    public html = ''
    public path
    public request
    public response
    public error

    public constructor(props : Props) {
        this.path = props.path
        this.request = props.request
        this.response = props.response
        this.error = props.error || false
    }

    render() : string {
        return ''
    }

    compile() {
        return TemplateEngine(this.render(), this.model)
    }

}

export default Controller