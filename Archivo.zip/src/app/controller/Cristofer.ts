import Controller from "../../base/controller/Controller";

class Cristofer  extends Controller{
    public model = {
        skills: ["Cristofer"],
        showSkills: true
    }

    public constructor(props) {
        super(props)
    }

    public render(): string {
        return (
            'My skills:' + 
            '<%if(this.showSkills) {%>' +
                '<%for(var index in this.skills) {%>' + 
                '<a href="#"><%this.skills[index]%></a>' +
                '<%}%>' +
            '<%} else {%>' +
                '<p>none</p>' +
            '<%}%>'
        );
    }
}

export default Cristofer