import Controller from "../../base/controller/Controller";

class Bie extends Controller {

    public model = {
        skills: ["js", "html", "css"],
        showSkills: false
    }

    public constructor(props) {
        super(props)
        this.model.skills.push('Claudio')
    }

    public render(): string {
        return (
            'My skills:' + 
            '<%if(this.showSkills) {%>' +
                '<%for(var index in this.skills) {%>' + 
                '<a href="#"><%this.skills[index]%></a>' +
                '<%}%>' +
            '<%} else {%>' +
                '<p>none</p>' +
            '<%}%>'
        );
    }
}

export default Bie