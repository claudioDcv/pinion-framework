class Props {
    public path
    public request
    public response
    public error : any
}

export default Props