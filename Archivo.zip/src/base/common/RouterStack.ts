import Route from './Route'
import Controller from '../controller/Controller';
import Props from '../controller/Props';

class RouterStack {
    private routerList : Array<Route> = []
    
    public register(route : Route) {
        this.routerList.push(route)
    }

    public getRouterList() : Array<Route> {
        return this.routerList
    }

    public routeResolve(path, request, response) {
        // Exclude ico
        if (path != '/favicon.ico') {
            const route : Route = this.getRouterList().find((route : Route) => route.name === path )
            
            if (route == null) {

                class Error {
                    public code = 500
                    public message = 'Error de servidor'
                }

                const error = new Error

                const defaultController = new Controller({ path, request, response, error: Error })
                return new Buffer(defaultController.compile(), 'utf8')    
            }
            const controller : Controller = route.makeController({ path, request, response })
            return new Buffer(controller.compile(), 'utf8')
        }
    }
}


export default RouterStack